#!/bin/bash
# Start the LiveVoiceTranscriptor worker
set -e

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PROJECT_ROOT="$(dirname "$SCRIPT_DIR")"

cd "$PROJECT_ROOT"

# Load env if available
if [ -f .env ]; then
    export $(grep -v '^#' .env | xargs)
fi

export PYTHONPATH="$PROJECT_ROOT"

echo "Starting LiveVoiceTranscriptor worker..."
echo "Sessions dir: ${SESSIONS_DIR:-./data/sessions}"
echo "Redis: ${REDIS_HOST:-localhost}:${REDIS_PORT:-6379}"
echo "Models dir: ${MODELS_DIR}"

python -m app.workers.worker
