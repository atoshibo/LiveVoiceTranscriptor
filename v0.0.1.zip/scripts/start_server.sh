#!/bin/bash
# Start the LiveVoiceTranscriptor server
set -e

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PROJECT_ROOT="$(dirname "$SCRIPT_DIR")"

cd "$PROJECT_ROOT"

# Load env if available
if [ -f .env ]; then
    export $(grep -v '^#' .env | xargs)
fi

export PYTHONPATH="$PROJECT_ROOT"

echo "Starting LiveVoiceTranscriptor server..."
echo "Sessions dir: ${SESSIONS_DIR:-./data/sessions}"
echo "Redis: ${REDIS_HOST:-localhost}:${REDIS_PORT:-6379}"

python -m uvicorn app.main:app \
    --host "${SERVER_HOST:-0.0.0.0}" \
    --port "${SERVER_PORT:-8000}" \
    --reload
