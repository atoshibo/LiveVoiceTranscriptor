@echo off
REM Start the LiveVoiceTranscriptor server on Windows

set SCRIPT_DIR=%~dp0
set PROJECT_ROOT=%SCRIPT_DIR%..

cd /d %PROJECT_ROOT%

set PYTHONPATH=%PROJECT_ROOT%

echo Starting LiveVoiceTranscriptor server...
python -m uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload
