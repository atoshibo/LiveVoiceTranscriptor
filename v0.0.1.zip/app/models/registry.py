"""
Model Registry - Central catalog of all available ASR models.

Key change from old project: Whisper Turbo is removed from the default pipeline.
Parakeet replaces it as candidate B.

Default pipeline models:
  - first pass: faster-whisper:medium
  - candidate A: faster-whisper:large-v3
  - candidate B: nemo-asr:parakeet-tdt-0.6b-v3
  - reconciler: local LLM / deterministic fallback

Canary is kept as optional upgrade but NOT in the default pipeline path.
"""
import os
import logging
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional

from app.core.config import get_config

logger = logging.getLogger(__name__)

PROVIDER_STABLE = "stable"
PROVIDER_EXPERIMENTAL = "experimental"
PROVIDER_BROKEN = "broken"
PROVIDER_UNSUPPORTED = "unsupported"


@dataclass
class ModelCapabilities:
    transcription: bool = True
    multilingual: bool = False
    partial_preview_safe: bool = False
    full_job_safe: bool = True
    retranscription_safe: bool = True
    language_auto_detect: bool = False


@dataclass
class ModelInfo:
    model_id: str
    display_name: str
    provider: str
    model_path: str = ""
    capabilities: ModelCapabilities = field(default_factory=ModelCapabilities)
    installed: bool = False
    languages: Optional[List[str]] = None  # None = all languages
    notes: str = ""
    provider_status: str = PROVIDER_STABLE

    @property
    def is_usable(self) -> bool:
        return self.installed and self.provider_status in (PROVIDER_STABLE, PROVIDER_EXPERIMENTAL)

    @property
    def selectable_for_canonical(self) -> bool:
        return self.installed and self.provider_status == PROVIDER_STABLE and self.capabilities.full_job_safe

    @property
    def selectable_for_retranscription(self) -> bool:
        return self.is_usable and self.capabilities.retranscription_safe

    @property
    def selectable_for_segmented(self) -> bool:
        return self.selectable_for_retranscription

    def to_dict(self) -> dict:
        return {
            "model_id": self.model_id,
            "display_name": self.display_name,
            "provider": self.provider,
            "model_path": self.model_path,
            "capabilities": {
                "transcription": self.capabilities.transcription,
                "multilingual": self.capabilities.multilingual,
                "partial_preview_safe": self.capabilities.partial_preview_safe,
                "full_job_safe": self.capabilities.full_job_safe,
                "retranscription_safe": self.capabilities.retranscription_safe,
                "language_auto_detect": self.capabilities.language_auto_detect,
            },
            "installed": self.installed,
            "languages": self.languages,
            "notes": self.notes,
            "provider_status": self.provider_status,
            "is_usable": self.is_usable,
            "selectable_for_canonical": self.selectable_for_canonical,
            "selectable_for_retranscription": self.selectable_for_retranscription,
            "selectable_for_segmented": self.selectable_for_segmented,
        }


def _model_dir_installed(path: str) -> bool:
    """Check if a model directory exists and is non-empty."""
    if not path:
        return False
    p = Path(path)
    return p.is_dir() and any(p.iterdir())


def _nemo_model_installed(path: str) -> bool:
    """Check if a .nemo file > 1MB exists in the directory."""
    if not path:
        return False
    p = Path(path)
    if not p.is_dir():
        return False
    for f in p.iterdir():
        if f.suffix == ".nemo" and f.stat().st_size > 1_000_000:
            return True
    return False


def _hf_model_installed(path: str) -> bool:
    """Check if HuggingFace model weights exist."""
    if not path:
        return False
    p = Path(path)
    if not p.is_dir():
        return False
    for f in p.iterdir():
        if f.name in ("pytorch_model.bin", "model.safetensors") or f.suffix == ".safetensors":
            return True
    return False


# Registry cache
_registry_cache: Optional[Dict[str, ModelInfo]] = None


def _build_registry() -> Dict[str, ModelInfo]:
    """Build the complete model registry."""
    cfg = get_config()
    mp = cfg.model_paths
    registry: Dict[str, ModelInfo] = {}

    # faster-whisper models (always "installed" - auto-download by CTranslate2)
    for size in ("tiny", "base", "small", "medium", "large-v2", "large-v3"):
        mid = f"faster-whisper:{size}"
        registry[mid] = ModelInfo(
            model_id=mid,
            display_name=f"Faster Whisper {size.title()}",
            provider="faster_whisper",
            model_path=size,  # CTranslate2 handles download
            capabilities=ModelCapabilities(
                transcription=True,
                multilingual=(size not in ("tiny", "base")),
                partial_preview_safe=True,
                full_job_safe=True,
                retranscription_safe=True,
                language_auto_detect=True,
            ),
            installed=True,
            languages=None,
            provider_status=PROVIDER_STABLE,
        )

    # Parakeet TDT 0.6B v3 - REPLACES Whisper Turbo as candidate B
    parakeet_path = mp.parakeet_path or ""
    registry["nemo-asr:parakeet-tdt-0.6b-v3"] = ModelInfo(
        model_id="nemo-asr:parakeet-tdt-0.6b-v3",
        display_name="NVIDIA Parakeet TDT 0.6B v3",
        provider="nemo_asr",
        model_path=parakeet_path,
        capabilities=ModelCapabilities(
            transcription=True,
            multilingual=False,  # Honest: Parakeet is English-only
            partial_preview_safe=False,
            full_job_safe=True,
            retranscription_safe=True,
            language_auto_detect=False,
        ),
        installed=_nemo_model_installed(parakeet_path),
        languages=["en"],  # Honest language coverage - English only
        notes="Replaces Whisper Turbo as candidate B. English-only; degrades gracefully for non-English.",
        provider_status=PROVIDER_EXPERIMENTAL,
    )

    # Canary 1B v2 - optional upgrade, NOT in default pipeline
    canary_path = mp.canary_path or ""
    registry["nemo-asr:canary-1b-v2"] = ModelInfo(
        model_id="nemo-asr:canary-1b-v2",
        display_name="NVIDIA Canary 1B v2",
        provider="nemo_asr",
        model_path=canary_path,
        capabilities=ModelCapabilities(
            transcription=True,
            multilingual=True,
            partial_preview_safe=False,
            full_job_safe=True,
            retranscription_safe=True,
            language_auto_detect=False,
        ),
        installed=_nemo_model_installed(canary_path),
        languages=["en", "es", "fr", "de"],
        notes="Optional precision upgrade. Not in default pipeline. Use explicitly when multilingual accuracy needed.",
        provider_status=PROVIDER_EXPERIMENTAL,
    )

    # Whisper Large V3 Turbo HF - REMOVED from default pipeline, kept for reference only
    turbo_path = mp.whisper_turbo_path or ""
    registry["transformers-whisper:whisper-large-v3-turbo-hf"] = ModelInfo(
        model_id="transformers-whisper:whisper-large-v3-turbo-hf",
        display_name="Whisper Large V3 Turbo (HF) [DEPRECATED]",
        provider="transformers_whisper",
        model_path=turbo_path,
        capabilities=ModelCapabilities(
            transcription=True,
            multilingual=True,
            partial_preview_safe=False,
            full_job_safe=True,
            retranscription_safe=True,
            language_auto_detect=True,
        ),
        installed=_hf_model_installed(turbo_path),
        languages=None,
        notes="DEPRECATED: Removed from default pipeline. Replaced by Parakeet. Available for manual retranscription only.",
        provider_status=PROVIDER_EXPERIMENTAL,
    )

    return registry


def get_registry(refresh: bool = False) -> Dict[str, ModelInfo]:
    global _registry_cache
    if _registry_cache is None or refresh:
        _registry_cache = _build_registry()
    return _registry_cache


def resolve_model_id(model_id_or_size: str) -> str:
    """Accept full model IDs or legacy size names."""
    if ":" in model_id_or_size:
        return model_id_or_size
    # Legacy size name -> faster-whisper
    return f"faster-whisper:{model_id_or_size}"


def get_model_info(model_id: str) -> Optional[ModelInfo]:
    reg = get_registry()
    return reg.get(model_id)


def list_installed_models() -> List[ModelInfo]:
    return [m for m in get_registry().values() if m.installed]


def list_usable_models() -> List[ModelInfo]:
    return [m for m in get_registry().values() if m.is_usable]


def list_all_models() -> List[ModelInfo]:
    return list(get_registry().values())


def is_model_safe_for_language(model_id: str, language: Optional[str]) -> bool:
    info = get_model_info(model_id)
    if not info:
        return False
    if info.languages is None:
        return True
    if language is None:
        return info.capabilities.language_auto_detect
    return language in info.languages


# Default pipeline model configuration
DEFAULT_FIRST_PASS = "faster-whisper:medium"
DEFAULT_CANDIDATE_A = "faster-whisper:large-v3"
# Parakeet replaces turbo as candidate B
DEFAULT_CANDIDATE_B = "nemo-asr:parakeet-tdt-0.6b-v3"

VALID_MODEL_SIZES = ("tiny", "base", "small", "medium", "large-v2", "large-v3")
