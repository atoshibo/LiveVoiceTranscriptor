"""
Main application entry point.

FastAPI server with:
  - CORS middleware
  - Auth middleware for /api/ paths
  - API v2 router (full backward compat)
  - Legacy routes (/health, /api/health, /api/sessions, etc.)
  - Browser UI at /
"""
import os
import sys
import logging
from pathlib import Path
from datetime import datetime, timezone

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse, JSONResponse
from starlette.middleware.base import BaseHTTPMiddleware

# Add project root to path
PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

from app.core.config import get_config
from app.api.api_v2 import router as api_v2_router
from app.api.auth import _extract_token
from app.storage.session_store import list_sessions
from app.core.atomic_io import safe_read_json

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(name)s: %(message)s")
logger = logging.getLogger(__name__)

app = FastAPI(title="LiveVoiceTranscriptor", version="2.0.0")

# CORS - permissive for dev
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# Auth middleware
class AuthMiddleware(BaseHTTPMiddleware):
    PUBLIC_PATHS = {"/", "/health", "/api/health", "/api/v2/health"}

    async def dispatch(self, request: Request, call_next):
        path = request.url.path
        # Skip auth for public paths
        if path in self.PUBLIC_PATHS or path.startswith("/api/v2/health"):
            return await call_next(request)
        # Skip auth for non-API paths (static, UI)
        if not path.startswith("/api/"):
            return await call_next(request)
        # Check auth
        cfg = get_config()
        token = _extract_token(request)
        if cfg.auth.token:
            if not token or token != cfg.auth.token:
                return JSONResponse(
                    status_code=401,
                    content={"detail": "Authentication required. Use 'Authorization: Bearer <token>' header."},
                    headers={"WWW-Authenticate": "Bearer"},
                )
        return await call_next(request)


app.add_middleware(AuthMiddleware)


# Startup
@app.on_event("startup")
async def startup():
    cfg = get_config()
    Path(cfg.storage.sessions_dir).mkdir(parents=True, exist_ok=True)
    logger.info(f"Sessions dir: {cfg.storage.sessions_dir}")
    # Ping Redis
    try:
        import redis
        r = redis.Redis(host=cfg.redis.host, port=cfg.redis.port)
        r.ping()
        logger.info(f"Redis connected: {cfg.redis.host}:{cfg.redis.port}")
    except Exception as e:
        logger.warning(f"Redis not available: {e}")


# Mount API v2 router
app.include_router(api_v2_router)


# ============================================================
# Legacy routes (NOT under /api/v2)
# ============================================================

@app.get("/health")
async def health():
    return {"ok": True, "service": "web"}


@app.get("/api/health")
async def api_health():
    return {"ok": True, "service": "web"}


@app.get("/api/sessions")
async def legacy_list_sessions():
    """Legacy session listing."""
    sessions = list_sessions(limit=100)
    return {"sessions": sessions}


@app.get("/api/diagnostics")
async def diagnostics():
    """System diagnostics."""
    cfg = get_config()
    redis_info = {"ok": False, "error": None, "queue_len": 0}
    try:
        import redis
        r = redis.Redis(host=cfg.redis.host, port=cfg.redis.port)
        r.ping()
        redis_info["ok"] = True
        redis_info["queue_len"] = r.llen(cfg.redis.queue) or 0
    except Exception as e:
        redis_info["error"] = str(e)

    gpu_info = {"available": False}
    try:
        import torch
        gpu_info["available"] = torch.cuda.is_available()
        if gpu_info["available"]:
            gpu_info["name"] = torch.cuda.get_device_name(0)
    except ImportError:
        gpu_info["error"] = "torch not installed"

    return {
        "redis": redis_info,
        "sessions_dir": cfg.storage.sessions_dir,
        "gpu": gpu_info,
    }


@app.get("/api/selftest")
async def selftest():
    """Smoke test - try loading a tiny model."""
    try:
        from faster_whisper import WhisperModel
        return {"ok": True, "details": "faster_whisper importable"}
    except ImportError:
        return {"ok": False, "details": "faster_whisper not installed"}
    except Exception as e:
        return {"ok": False, "details": str(e)}


# ============================================================
# Browser UI
# ============================================================

@app.get("/", response_class=HTMLResponse)
async def root():
    """Serve the browser UI."""
    from app.ui.dashboard import get_ui_html
    return HTMLResponse(content=get_ui_html())


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "app.main:app",
        host=os.environ.get("SERVER_HOST", "0.0.0.0"),
        port=int(os.environ.get("SERVER_PORT", "8000")),
        reload=True,
    )
