"""
Central configuration for LiveVoiceTranscriptor.

All pipeline geometry, model paths, storage paths, and runtime limits
are configured here. Environment variables override defaults.
"""
import os
from pathlib import Path
from dataclasses import dataclass, field
from typing import Optional, List

def _env(key: str, default: str = "") -> str:
    return os.environ.get(key, default)

def _env_int(key: str, default: int = 0) -> int:
    return int(os.environ.get(key, str(default)))

def _env_float(key: str, default: float = 0.0) -> float:
    return float(os.environ.get(key, str(default)))

def _env_bool(key: str, default: bool = False) -> bool:
    val = os.environ.get(key, str(default)).lower()
    return val in ("true", "1", "yes")

# ---------------------------------------------------------------------------
# Project root detection
# ---------------------------------------------------------------------------
PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent
DEFAULT_MODELS_DIR = str(Path(os.environ.get(
    "MODELS_DIR",
    r"C:\Users\akova\OneDrive\Documents\DevOurs\VoiceRecordTranscriptor\models"
)))


@dataclass(frozen=True)
class PipelineGeometry:
    """Frozen pipeline geometry from canonical spec."""
    transport_chunk_ms: int = 30000
    decode_window_ms: int = 30000
    decode_stride_ms: int = 15000
    commit_stripe_ms: int = 15000


@dataclass(frozen=True)
class StorageConfig:
    sessions_dir: str = ""

    def __post_init__(self):
        val = _env("SESSIONS_DIR", str(PROJECT_ROOT / "data" / "sessions"))
        object.__setattr__(self, "sessions_dir", val)


@dataclass(frozen=True)
class RedisConfig:
    host: str = ""
    port: int = 6379
    queue: str = "transcription_jobs"
    partial_queue: str = ""

    def __post_init__(self):
        object.__setattr__(self, "host", _env("REDIS_HOST", "localhost"))
        object.__setattr__(self, "port", _env_int("REDIS_PORT", 6379))
        object.__setattr__(self, "queue", _env("REDIS_QUEUE", "transcription_jobs"))
        object.__setattr__(self, "partial_queue",
                          _env("REDIS_PARTIAL_QUEUE", f"{self.queue}_partial"))


@dataclass(frozen=True)
class AuthConfig:
    token: str = ""

    def __post_init__(self):
        object.__setattr__(self, "token", _env("AUTH_TOKEN", ""))


@dataclass(frozen=True)
class RateLimitConfig:
    general_per_minute: int = 60
    upload_per_minute: int = 300

    def __post_init__(self):
        object.__setattr__(self, "general_per_minute",
                          _env_int("RATE_LIMIT_GENERAL_PER_MINUTE",
                                   _env_int("RATE_LIMIT_PER_MINUTE", 60)))
        object.__setattr__(self, "upload_per_minute",
                          _env_int("RATE_LIMIT_UPLOAD_PER_MINUTE", 300))


@dataclass(frozen=True)
class WorkerConfig:
    concurrency: int = 1
    partial_every_n_chunks: int = 5
    partial_cooldown_seconds: int = 120
    max_chunk_mb: int = 30
    max_session_chunks: int = 500
    strict_cuda: bool = False

    def __post_init__(self):
        object.__setattr__(self, "concurrency", _env_int("WORKER_CONCURRENCY", 1))
        object.__setattr__(self, "partial_every_n_chunks", _env_int("PARTIAL_EVERY_N_CHUNKS", 5))
        object.__setattr__(self, "partial_cooldown_seconds", _env_int("PARTIAL_COOLDOWN_SECONDS", 120))
        object.__setattr__(self, "max_chunk_mb", _env_int("MAX_CHUNK_MB", 30))
        object.__setattr__(self, "max_session_chunks", _env_int("MAX_SESSION_CHUNKS", 500))
        object.__setattr__(self, "strict_cuda", _env_bool("STRICT_CUDA", False))


@dataclass(frozen=True)
class ModelPaths:
    """Central model path configuration. Resolves both friendly names and HF cache style dirs."""
    models_dir: str = ""

    def __post_init__(self):
        object.__setattr__(self, "models_dir", _env("MODELS_DIR", DEFAULT_MODELS_DIR))

    def resolve(self, name: str, env_override: str = "") -> Optional[str]:
        """Resolve a model path by trying env override, friendly name, and HF cache name."""
        if env_override:
            override = _env(env_override, "")
            if override and os.path.isdir(override):
                return override

        base = Path(self.models_dir)
        if not base.is_dir():
            return None

        # Try direct name
        candidate = base / name
        if candidate.is_dir():
            return str(candidate)

        # Try HF cache style: models--org--name
        for entry in base.iterdir():
            if entry.is_dir() and name in entry.name:
                # Check for snapshot dirs in HF cache
                snapshots = entry / "snapshots"
                if snapshots.is_dir():
                    # Return the latest snapshot
                    snapshot_dirs = sorted(snapshots.iterdir(), key=lambda p: p.stat().st_mtime, reverse=True)
                    if snapshot_dirs:
                        return str(snapshot_dirs[0])
                return str(entry)

        return None

    @property
    def parakeet_path(self) -> Optional[str]:
        return self.resolve("parakeet-tdt-0.6b-v3", "PARAKEET_MODEL_PATH")

    @property
    def canary_path(self) -> Optional[str]:
        return self.resolve("canary-1b-v2", "CANARY_MODEL_PATH")

    @property
    def whisper_turbo_path(self) -> Optional[str]:
        return self.resolve("whisper-large-v3-turbo-hf", "WHISPER_TURBO_MODEL_PATH")

    @property
    def diarization_path(self) -> Optional[str]:
        return self.resolve("pyannote-speaker-diarization-community-1", "DIARIZATION_MODEL_PATH")

    @property
    def llm_path(self) -> Optional[str]:
        """Resolve LLM model path (GGUF file)."""
        override = _env("LLM_MODEL_PATH", "")
        if override and os.path.isfile(override):
            return override
        base = Path(self.models_dir)
        for f in base.iterdir():
            if f.suffix == ".gguf":
                return str(f)
        return None


@dataclass(frozen=True)
class DiarizationConfig:
    enabled_by_default: bool = False
    min_speakers: int = 1
    max_speakers: int = 10
    min_duration_on: float = 0.3
    min_duration_off: float = 0.3
    use_gpu: bool = True
    fallback_on_error: bool = True


@dataclass(frozen=True)
class ReconciliationConfig:
    min_confidence: float = 0.3
    max_tokens: int = 300
    temperature: float = 0.1
    use_llm: bool = True
    fallback_to_deterministic: bool = True


@dataclass
class AppConfig:
    """Top-level application configuration aggregate."""
    geometry: PipelineGeometry = field(default_factory=PipelineGeometry)
    storage: StorageConfig = field(default_factory=StorageConfig)
    redis: RedisConfig = field(default_factory=RedisConfig)
    auth: AuthConfig = field(default_factory=AuthConfig)
    rate_limit: RateLimitConfig = field(default_factory=RateLimitConfig)
    worker: WorkerConfig = field(default_factory=WorkerConfig)
    model_paths: ModelPaths = field(default_factory=ModelPaths)
    diarization: DiarizationConfig = field(default_factory=DiarizationConfig)
    reconciliation: ReconciliationConfig = field(default_factory=ReconciliationConfig)


# Singleton
_config: Optional[AppConfig] = None

def get_config() -> AppConfig:
    global _config
    if _config is None:
        _config = AppConfig()
    return _config

def reset_config():
    """Reset config singleton (useful for testing)."""
    global _config
    _config = None
