"""
Stage 8 - Stabilization and Canonical Assembly

After stripe reconciliation, assembles canonical segments.

Stabilization logic:
  - provisional_partial: from current available support only
  - stabilized_partial: from stripe(s) with minimum support
  - final_transcript: from canonical stabilized segments only

Adjacent compatible stripes are merged into canonical segments.
Each segment retains full provenance.

Output: canonical/ with canonical_segments.json and transcript surfaces
"""
import logging
from typing import List, Dict, Optional

from app.core.atomic_io import atomic_write_json, atomic_write_text
from app.storage.session_store import session_dir

logger = logging.getLogger(__name__)


def stabilize_stripes(reconciliation_records: List[Dict],
                      stripe_packets: List[Dict] = None) -> List[Dict]:
    """Determine stabilization state for each reconciled stripe.

    A stripe becomes stabilized when:
    1. It has evidence from at least 2 supporting windows, OR
    2. It is the first/last stripe (edge case)
    """
    stabilized = []

    for record in reconciliation_records:
        stripe_id = record.get("stripe_id", "")
        support_count = 1  # Default

        # Look up support info from stripe packets
        if stripe_packets:
            for sp in stripe_packets:
                if sp.get("stripe_id") == stripe_id:
                    support_count = sp.get("support_window_count", 1)
                    break

        state = "stabilized" if support_count >= 2 else "provisional"

        stabilized.append({
            **record,
            "stabilization_state": state,
            "support_window_count": support_count,
        })

    return stabilized


def merge_into_segments(stabilized_stripes: List[Dict]) -> List[Dict]:
    """Merge adjacent compatible stripes into canonical segments.

    Segments are the lowest user-facing truth unit.
    Adjacent stripes with the same source model and language can merge.
    """
    if not stabilized_stripes:
        return []

    # Sort by start_ms
    sorted_stripes = sorted(stabilized_stripes, key=lambda s: s["start_ms"])

    segments = []
    current = None

    for stripe in sorted_stripes:
        text = stripe.get("chosen_text", "").strip()
        if not text:
            continue

        if current is None:
            current = {
                "start_ms": stripe["start_ms"],
                "end_ms": stripe["end_ms"],
                "text": text,
                "source_model": stripe.get("chosen_source", "unknown"),
                "confidence": stripe.get("confidence", 0.0),
                "stabilization_state": stripe.get("stabilization_state", "provisional"),
                "support_windows": set(),
                "support_models": set(),
                "stripes": [stripe["stripe_id"]],
            }
            # Collect provenance
            if stripe.get("chosen_source"):
                current["support_models"].add(stripe["chosen_source"])
            continue

        # Check if we can merge with current
        can_merge = (
            stripe["start_ms"] <= current["end_ms"] + 1000 and  # Adjacent or slight gap
            stripe.get("chosen_source") == current["source_model"]
        )

        if can_merge:
            # Merge
            current["end_ms"] = stripe["end_ms"]
            current["text"] = _dedup_join(current["text"], text)
            current["confidence"] = (current["confidence"] + stripe.get("confidence", 0)) / 2
            current["stripes"].append(stripe["stripe_id"])
            if stripe.get("stabilization_state") == "provisional":
                current["stabilization_state"] = "provisional"
            if stripe.get("chosen_source"):
                current["support_models"].add(stripe["chosen_source"])
        else:
            # Finalize current and start new
            current["support_windows"] = sorted(current["support_windows"])
            current["support_models"] = sorted(current["support_models"])
            segments.append(current)
            current = {
                "start_ms": stripe["start_ms"],
                "end_ms": stripe["end_ms"],
                "text": text,
                "source_model": stripe.get("chosen_source", "unknown"),
                "confidence": stripe.get("confidence", 0.0),
                "stabilization_state": stripe.get("stabilization_state", "provisional"),
                "support_windows": set(),
                "support_models": set(),
                "stripes": [stripe["stripe_id"]],
            }
            if stripe.get("chosen_source"):
                current["support_models"].add(stripe["chosen_source"])

    # Don't forget last segment
    if current:
        current["support_windows"] = sorted(current["support_windows"])
        current["support_models"] = sorted(current["support_models"])
        segments.append(current)

    # Assign segment IDs
    for i, seg in enumerate(segments):
        seg["segment_id"] = f"seg_{i:06d}"
        seg["speaker"] = None  # Will be set by selective enrichment

    return segments


def _dedup_join(text_a: str, text_b: str, max_overlap_words: int = 12,
                min_overlap_words: int = 2) -> str:
    """Join two text segments with overlap deduplication.

    Finds the longest word sequence that is simultaneously a suffix of
    text_a and a prefix of text_b, then strips that prefix from text_b.
    """
    words_a = text_a.split()
    words_b = text_b.split()

    if not words_a or not words_b:
        return f"{text_a} {text_b}".strip()

    # Search for longest overlap from max_overlap_words down to min_overlap_words
    for overlap_len in range(min(max_overlap_words, len(words_a), len(words_b)),
                             min_overlap_words - 1, -1):
        suffix_a = " ".join(words_a[-overlap_len:]).lower()
        prefix_b = " ".join(words_b[:overlap_len]).lower()
        if suffix_a == prefix_b:
            # Found overlap - strip prefix from text_b
            return text_a + " " + " ".join(words_b[overlap_len:])

    # No overlap found
    return f"{text_a} {text_b}".strip()


def build_transcript_surfaces(segments: List[Dict], session_id: str) -> Dict:
    """Build user-facing transcript surfaces from canonical segments."""
    sd = session_dir(session_id)
    canonical_dir = sd / "canonical"

    # Plain text
    text = " ".join(seg["text"] for seg in segments if seg.get("text"))

    # Segments with provenance
    output_segments = []
    for seg in segments:
        output_segments.append({
            "segment_id": seg["segment_id"],
            "start_ms": seg["start_ms"],
            "end_ms": seg["end_ms"],
            "speaker": seg.get("speaker"),
            "text": seg.get("text", ""),
            "language": seg.get("language"),
            "confidence": seg.get("confidence", 0.0),
            "support_windows": seg.get("support_windows", []),
            "support_models": seg.get("support_models", []),
            "stabilization_state": seg.get("stabilization_state", "provisional"),
            "corruption_flags": [],
        })

    # Words list
    words = []
    for seg in segments:
        words.append({
            "t_ms": seg["start_ms"],
            "speaker": seg.get("speaker", "SPEAKER_00"),
            "w": seg.get("text", ""),
        })

    # Provenance
    provenance = {
        "session_id": session_id,
        "segment_count": len(segments),
        "assembly_method": "canonical_stripe_reconciliation",
        "segments": [
            {
                "segment_id": seg["segment_id"],
                "stripes": seg.get("stripes", []),
                "source_model": seg.get("source_model"),
                "confidence": seg.get("confidence"),
                "stabilization_state": seg.get("stabilization_state"),
            }
            for seg in segments
        ],
    }

    # Persist
    atomic_write_text(str(canonical_dir / "transcript.txt"), text)
    atomic_write_json(str(canonical_dir / "canonical_segments.json"), {
        "session_id": session_id,
        "segment_count": len(output_segments),
        "segments": output_segments,
    })
    atomic_write_json(str(canonical_dir / "provenance.json"), provenance)

    return {
        "text": text,
        "segments": output_segments,
        "words": words,
        "provenance": provenance,
    }


def run_canonical_assembly(session_id: str, reconciliation_result: Dict,
                           stripe_packets: List[Dict], stage) -> Dict:
    """Execute canonical assembly stage.

    1. Stabilize stripes
    2. Merge into segments
    3. Build transcript surfaces
    """
    records = reconciliation_result.get("records", [])
    stabilized = stabilize_stripes(records, stripe_packets)
    segments = merge_into_segments(stabilized)
    surfaces = build_transcript_surfaces(segments, session_id)

    stage.commit(["transcript.txt", "canonical_segments.json", "provenance.json"])

    return {
        "segment_count": len(segments),
        "stabilized_count": sum(1 for s in segments if s.get("stabilization_state") == "stabilized"),
        "provisional_count": sum(1 for s in segments if s.get("stabilization_state") == "provisional"),
        "text_length": len(surfaces["text"]),
        "surfaces": surfaces,
    }
